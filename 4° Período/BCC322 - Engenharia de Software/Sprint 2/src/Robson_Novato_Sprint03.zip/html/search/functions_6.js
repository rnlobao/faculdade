var searchData=
[
  ['model_0',['Model',['../classModel.html#ae3b375de5f6df4faf74a95d64748e048',1,'Model::Model()'],['../classModel.html#a6a108a568d0854408c888f82da4acff8',1,'Model::Model(string name=&quot;&quot;, double time=0.0)']]]
];
