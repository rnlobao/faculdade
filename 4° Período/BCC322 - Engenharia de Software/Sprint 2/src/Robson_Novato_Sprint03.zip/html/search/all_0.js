var searchData=
[
  ['add_0',['add',['../classModel.html#ad7e1460343a74a56fe20f417c1852eee',1,'Model::add(System *sys)'],['../classModel.html#ab69613bde0ace81c92bbf519660ccb2c',1,'Model::add(Flow *flow)']]]
];
