# ifndef buscabinaria_h
# define buscabinaria_h

double BuscaBinaria(double area, double remove[], int n, double inicio, double final);
void PrintResultado(double metrosquadradosremovidos, double a, double remove[], int n, double maior);
void HappyFace();
void SadFace();

# endif